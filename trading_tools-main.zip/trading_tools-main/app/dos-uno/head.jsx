export default function Head() {
  return (
    <>
      <title>Dos A Uno</title>
    </>
  )
}
