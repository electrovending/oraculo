export default function Head() {
  return (
    <>
      <title>Oraculo App</title>
    </>
  )
}
