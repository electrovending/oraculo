export default function Head() {
  return (
    <>
      <title>VIP</title>
    </>
  )
}
