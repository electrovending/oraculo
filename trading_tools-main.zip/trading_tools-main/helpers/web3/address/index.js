export const OGTAddress = '0x598642F59c0366643C6F9ee3252cBB3Ef1524C51'
export const BNBTokenAddress = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c' //BNB
export const USDTokenAddress = '0x55d398326f99059fF775485246999027B3197955' //USDT
export const pancakeSwapContract =
  '0x10ED43C718714eb63d5aA57B78B54704E256024E'.toLowerCase()
